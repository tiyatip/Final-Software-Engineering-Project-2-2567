import tkinter as tk
import os
import cv2
import sys
import numpy as np
from PIL import ImageTk, Image
from tkinter import filedialog
from os import path
from threading import *
import pandas as pd
from os import path
import os
import math
from tkinter import filedialog as fd
from tkinter import simpledialog
import time
import threading
import codecs

import glob
import os
import cv2
import math
import time
from tkinter.filedialog import askopenfilename
import random
import string
import subprocess
import matplotlib.pyplot as plt

from datetime import datetime
from time import time

from imutils import face_utils
import numpy as np
import argparse
import os
import imutils
import mediapipe as mp

from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import pandas as pd
import statistics as st

from os import path
import os

from keras.utils import np_utils
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.optimizers import Adam
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.layers import Activation, Flatten, Dense, Dropout
import math
import pandas as pd
from keras.models import Sequential
from keras.layers.core import Dense, Activation
from keras.utils import np_utils
from tkinter import ttk
from tkinter import filedialog as fd
import tensorflow as tf

class Detection():

    def __init__(self, ind):

        self.cap = cv2.VideoCapture(ind)
        self.cancel = False
        self.frame = []
        self.cancel = False
        self.mode = 0
        self.face_landmarks = []
        self.hand_landmarks = []
        self.results_pose_landmarks = []
        self.loaded_model = []
        self.counter = 0
        self.run_process = False

        # GUI
        self.mainWindow = tk.Tk()
        self.mainWindow.title('Landmark detection')
        self.mainWindow.resizable(width=False, height=False)

        self.window_height = 550
        self.window_width = 860

        self.screen_width = self.mainWindow.winfo_screenwidth()
        self.screen_height = self.mainWindow.winfo_screenheight()

        self.x_cordinate = int((self.screen_width / 2) - (self.window_width / 2))
        self.y_cordinate = int((self.screen_height / 2) - (self.window_height / 2))

        self.canvas = tk.Canvas(self.mainWindow, width=640, height=480)

        self.mainWindow.geometry(
            "{}x{}+{}+{}".format(self.window_width, self.window_height, self.x_cordinate, self.y_cordinate))

        self.panel = tk.Label(self.mainWindow, compound=tk.CENTER, anchor=tk.CENTER, bg="white")
        self.panel.place(x=10, y=10, bordermode="outside", height=480, width=640)

        self.label_frame_action = tk.LabelFrame(self.mainWindow, text=' Action ')
        self.label_frame_action.place(x=680, y=5, width=165, height=435)

        self.label_frame_select = tk.LabelFrame(self.mainWindow, text=' Class ')
        self.label_frame_select.place(x=680, y=440, width=165, height=60)

        self.button_webcam_start = tk.Button(self.label_frame_action, text="Start", command=self.start, height=3, width=20)
        self.button_webcam_start.place(x=15, y=10, width=130, height=40)

        self.button_webcam_stop = tk.Button(self.label_frame_action, text="Stop", command=self.stop, height=3, width=20)
        self.button_webcam_stop.place(x=15, y=55, width=130, height=40)

        self.button_webcam_face = tk.Button(self.label_frame_action, text="Face", command=self.face, height=3, width=20)
        self.button_webcam_face.place(x=15, y=100, width=130, height=40)

        self.button_webcam_hand = tk.Button(self.label_frame_action, text="Hand", command=self.hand, height=3, width=20)
        self.button_webcam_hand.place(x=15, y=145, width=130, height=40)

        self.button_webcam_body = tk.Button(self.label_frame_action, text="Body", command=self.body, height=3, width=20)
        self.button_webcam_body.place(x=15, y=190, width=130, height=40)

        self.button_webcam_save_csv = tk.Button(self.label_frame_action, text="Save to .csv", command=self.to_csv, height=3, width=20)
        self.button_webcam_save_csv.place(x=15, y=235, width=130, height=40)

        self.button_webcam_training = tk.Button(self.label_frame_action, text="Training", command=self.training, height=3, width=20)
        self.button_webcam_training.place(x=15, y=280, width=130, height=40)

        self.button_import_model = tk.Button(self.label_frame_action, text="Import model", command=self.import_model, height=3, width=20)
        self.button_import_model.place(x=15, y=325, width=130, height=40)

        self.txt_delay = tk.Label(self.label_frame_action, text="Delay : ")
        self.txt_delay.place(x=15, y=400, anchor='sw')
        self.textBox_delay = tk.Entry(self.label_frame_action, width=50, justify='center')
        self.textBox_delay.insert(0, 5)
        self.textBox_delay.place(x=60, y=380, width=50, height=20)
        self.txt_delay2 = tk.Label(self.label_frame_action, text="sec.")
        self.txt_delay2.place(x=115, y=400, anchor='sw')

        self.data_select = []
        self.var_select = tk.StringVar()
        self.combo_select = ttk.Combobox(self.label_frame_select, textvariable=self.var_select, width=18)
        self.combo_select.set('Class name')
        self.combo_select['values'] = self.data_select
        self.combo_select['state'] = 'readonly'
        self.combo_select.place(x=15, y=10)
        self.var_select.trace('w', self.get_index_select)

        self.button_webcam_exit = tk.Button(self.label_frame_action, text="Exit", command=self.Exit, height=3, width=20)
        self.button_webcam_exit.place(x=680, y=450, width=130, height=40)

        self.txt_delay_show = tk.Label(self.mainWindow, text="Delay : ", font=("Arial", 25), fg='red')
        self.txt_delay_show.place(x=15, y=540, anchor='sw')

        self.mainWindow.after(10, self.init)
        self.mainWindow.mainloop()

    def init(self):
        self.start()
        self.delay()

    def delay(self):
        self.t = threading.Timer(1, self.delay)

        self.counter += 1
        if self.counter > int(self.textBox_delay.get()):
            self.run_process = True
            self.counter = 0
        else:
            self.run_process = False

        self.txt_delay_show.config(text = 'Delay : ' + str(self.counter))

        self.t.start()

    def import_model(self):
        filetypes = (
            ('text files', '*.h5'),
            ('All files', '*.*')
        )

        self.filename = fd.askopenfilename(
            title='Open a file model',
            initialdir=os.getcwd(),
            filetypes=filetypes)

        self.loaded_model = tf.keras.models.load_model(self.filename)

        tmp = str(self.filename).split('/')
        f = str(tmp[len(tmp) - 1])
        if f == 'face_model.h5':
            self.mode = 0
        elif f == 'hand_model.h5':
            self.mode = 1
        elif f == 'body_model.h5':
            self.mode = 2

    def get_index_select(self, *arg):
        self.selected_select = self.var_select.get();
        print(self.selected_select)

    def feature_extraction(self, landmark, mode, action):

        data = []
        F = []
        Upper = []
        Lower = []

        if action == 'face':
            Upper = [61, 185, 40, 39, 37, 0, 267, 269, 270, 409]
            Lower = [146, 91, 181, 84, 17, 314, 405, 321, 375, 291]
        elif action == 'hand':
            Upper = [4, 8, 12, 16, 20]
            Lower = [0, 0, 0, 0, 0]
        elif action == 'body':
            Upper = [28, 26, 24, 12, 14, 27, 25, 23, 11, 13, 16, 15]
            Lower = [26, 24, 12, 14, 16, 25, 23, 11, 13, 15, 10, 9]

        if mode == 'classify': # testing
            tmp = []
            for i in landmark:
                D = str(i).replace('\n', ',').split(',')
                for i in D:
                    if i:
                        tmp.append(i)

            for k in range(0, len(tmp) - 1, 3):
                R = tmp[k:k + 3]
                try:
                    x = float(R[0].split(':')[1].strip())
                    y = float(R[1].split(':')[1].strip())
                    data.append([x, y])
                except Exception as ex:
                    data.append([0, 0])
        else: # training
            for k in range(0, len(landmark) - 1, 3):
                R = landmark[k:k + 3]
                try:
                    x = float(R[0].split(':')[1].strip())
                    y = float(R[1].split(':')[1].strip())
                    data.append([x, y])
                except Exception as ex:
                    data.append([0, 0])

        data_1 = [data[i] for i in Upper]
        data_2 = [data[i] for i in Lower]

        for j in range(len(data_1)):
            P1 = data_1[j]
            P2 = data_2[j]
            x1 = float(P1[0])
            y1 = float(P1[1])
            x2 = float(P2[0])
            y2 = float(P2[1])
            radians = math.atan2((y2 - y1), (x2 - x1))
            degrees = math.degrees(abs(radians))
            F.append(degrees)

        return F

    def train_model(self, mode):

        if mode == 'face':
            num_classes = 3
            dataFrame_face = pd.read_csv('face.csv')
            [r, c] = dataFrame_face.shape
            num_feature = 10
            class_name = 0
            count = r

            X_total = np.zeros((count, num_feature), dtype=float)
            Y_total = np.zeros((count), dtype=int)
            c_total = 0

            for i in range(r):

                data = []
                A = dataFrame_face.values[i, :]
                check_class = A[0]
                A = A[1:]

                if check_class == 'Smile':
                    class_name = 0
                elif check_class == 'Sad':
                    class_name = 1
                elif check_class == 'Angry':
                    class_name = 2

                R = self.feature_extraction(A , 'training', 'face')

                for j in range(len(R)):
                    X_total[c_total, j] = float(R[j])

                Y_total[c_total] = class_name
                c_total += 1

            #scaler = MinMaxScaler()
            #X_total = scaler.fit_transform(X_total)

            # Split train test
            X_train, X_test, y_train, y_test = train_test_split(X_total, Y_total, test_size=0.1, random_state=42)

            # Map class
            y_train = np_utils.to_categorical(y_train, num_classes)
            y_test = np_utils.to_categorical(y_test, num_classes)

            model = self.create_network(num_classes, num_feature)

            # define optimizer
            adam = Adam(lr=0.001)
            model.compile(optimizer=adam, loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()

            model_info = model.fit(X_train, y_train, batch_size=32, epochs=500, verbose=2, validation_data=(X_test, y_test))

            # save model
            model.save('face_model.h5')

            acc = self.accuracy(X_train, y_train, model)
            print("Accuracy train : {0:.4f} %".format(acc))

            # predict = model.predict(X_test)
            acc = self.accuracy(X_test, y_test, model)
            print("Accuracy test : {0:.4f} %".format(acc))

            self.plot_model_history(model_info)

        elif mode == 'hand':

            num_classes = 5
            dataFrame_face = pd.read_csv('hand.csv')
            [r, c] = dataFrame_face.shape
            num_feature = 5
            class_name = 0
            count = r

            X_total = np.zeros((count, num_feature), dtype=float)
            Y_total = np.zeros((count), dtype=int)
            c_total = 0

            for i in range(r):

                data = []
                A = dataFrame_face.values[i, :]
                check_class = A[0]
                A = A[1:]

                if check_class == 'One':
                    class_name = 0
                elif check_class == 'Two':
                    class_name = 1
                elif check_class == 'Three':
                    class_name = 2
                elif check_class == 'Four':
                    class_name = 3
                elif check_class == 'Five':
                    class_name = 4

                R = self.feature_extraction(A, 'training', 'hand')

                for j in range(len(R)):
                    X_total[c_total, j] = float(R[j])

                Y_total[c_total] = class_name
                c_total += 1

            # scaler = MinMaxScaler()
            # X_total = scaler.fit_transform(X_total)

            # Split train test
            X_train, X_test, y_train, y_test = train_test_split(X_total, Y_total, test_size=0.1, random_state=42)

            # Map class
            y_train = np_utils.to_categorical(y_train, num_classes)
            y_test = np_utils.to_categorical(y_test, num_classes)

            model = self.create_network(num_classes, num_feature)

            # define optimizer
            adam = Adam(lr=0.001)
            model.compile(optimizer=adam, loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()

            model_info = model.fit(X_train, y_train, batch_size=32, epochs=500, verbose=2,
                                   validation_data=(X_test, y_test))

            # save model
            model.save('hand_model.h5')

            acc = self.accuracy(X_train, y_train, model)
            print("Accuracy train : {0:.4f} %".format(acc))

            # predict = model.predict(X_test)
            acc = self.accuracy(X_test, y_test, model)
            print("Accuracy test : {0:.4f} %".format(acc))

            self.plot_model_history(model_info)

        elif mode == 'body':

            num_classes = 3
            dataFrame_face = pd.read_csv('body.csv')
            [r, c] = dataFrame_face.shape
            num_feature = 12
            class_name = 0
            count = r

            X_total = np.zeros((count, num_feature), dtype=float)
            Y_total = np.zeros((count), dtype=int)
            c_total = 0

            for i in range(r):

                data = []
                A = dataFrame_face.values[i, :]
                check_class = A[0]
                A = A[1:]

                if check_class == 'Raise right arm':
                    class_name = 0
                elif check_class == 'Raise left arm':
                    class_name = 1
                elif check_class == 'Spread both arm':
                    class_name = 2

                R = self.feature_extraction(A, 'training', 'body')

                for j in range(len(R)):
                    X_total[c_total, j] = float(R[j])

                Y_total[c_total] = class_name
                c_total += 1

            # scaler = MinMaxScaler()
            # X_total = scaler.fit_transform(X_total)

            # Split train test
            X_train, X_test, y_train, y_test = train_test_split(X_total, Y_total, test_size=0.1, random_state=42)

            # Map class
            y_train = np_utils.to_categorical(y_train, num_classes)
            y_test = np_utils.to_categorical(y_test, num_classes)

            model = self.create_network(num_classes, num_feature)

            # define optimizer
            adam = Adam(lr=0.001)
            model.compile(optimizer=adam, loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()

            model_info = model.fit(X_train, y_train, batch_size=32, epochs=500, verbose=2,
                                   validation_data=(X_test, y_test))

            # save model
            model.save('body_model.h5')

            acc = self.accuracy(X_train, y_train, model)
            print("Accuracy train : {0:.4f} %".format(acc))

            # predict = model.predict(X_test)
            acc = self.accuracy(X_test, y_test, model)
            print("Accuracy test : {0:.4f} %".format(acc))

            self.plot_model_history(model_info)

    def accuracy(self, test_x, test_y, model):
        result = model.predict(test_x)
        predicted_class = np.argmax(result, axis=1)
        true_class = np.argmax(test_y, axis=1)
        num_correct = np.sum(predicted_class == true_class)
        accuracy = float(num_correct) / result.shape[0]
        return (accuracy * 100)

    def plot_model_history(self, history):
        plt.subplot(211)
        plt.plot(history.history['accuracy'])
        plt.plot(history.history['val_accuracy'])
        plt.title('accuracy')
        plt.ylabel('accuracy')
        plt.xlabel('epoch')
        plt.legend(['train', 'val'], loc='upper right')

        plt.subplot(212)
        plt.plot(history.history['loss'])
        plt.plot(history.history['val_loss'])
        plt.title('loss')
        plt.ylabel('loss')
        plt.xlabel('epoch')
        plt.legend(['train', 'val'], loc='upper right')
        plt.show()

    def training(self):

        if self.mode == 0:
            self.train_model('face')
        elif self.mode == 1:
            self.train_model('hand')
        elif self.mode == 2:
            self.train_model('body')

    def create_network(self, num_class, num_feature):

        # initialize model
        model = Sequential()

        # add an input layer and a hidden layer
        model.add(Dense(512, input_dim=num_feature))
        model.add(Activation('relu'))
        model.add(Dense(256))
        model.add(Activation('relu'))
        model.add(Dense(128))
        model.add(Activation('relu'))
        model.add(Dense(64))
        model.add(Activation('relu'))

        # add output layer
        model.add(Dense(num_class))
        # add softmax layer
        model.add(Activation('softmax'))

        return model

    def to_csv(self):
        if self.mode == 0:  # Face
            with open("face.csv", "a") as file:
                self.tmp = self.selected_select + ','
                for i in self.face_landmarks.landmark:
                    self.tmp += str(i).replace('\n', ',')
                file.write(self.tmp + '\n')
        elif self.mode == 1:  # hand
            with open("hand.csv", "a") as file:
                self.tmp = self.selected_select + ','
                for i in self.hand_landmarks.landmark:
                    self.tmp += str(i).replace('\n', ',')
                file.write(self.tmp + '\n')
        elif self.mode == 2:  # body
            with open("body.csv", "a") as file:
                self.tmp = self.selected_select + ','
                for i in self.results_pose_landmarks.pose_landmarks.landmark:
                    self.tmp += str(i).replace('\n', ',')
                file.write(self.tmp + '\n')

    def face(self):
        self.tmp = ''
        self.combo_select['values'] = ['Smile', 'Sad', 'Angry']
        self.mode = 0

    def hand(self):
        self.tmp = ''
        self.combo_select['values'] = ['One', 'Two', 'Three', 'Four', 'Five']
        self.mode = 1

    def body(self):
        self.tmp = ''
        self.combo_select['values'] = ['Raise left arm', 'Raise right arm', 'Spread both arm']
        self.mode = 2

    def start(self):
        self.button_webcam_start['state'] = 'disabled'
        self.button_webcam_stop['state'] = 'normal'
        self.cancel = False
        self.play_video()

    def stop(self):
        self.cancel = True
        self.button_webcam_start['state'] = 'normal'
        self.button_webcam_stop['state'] = 'disabled'

    def play_video(self):

        if self.loaded_model:
            tmp = str(self.filename).split('/')
            f = str(tmp[len(tmp) - 1]).split('_')[0]
            self.mainWindow.title('Landmark detection [ Model ' + f + ' loaded ! ]')
        else:
            self.mainWindow.title('Landmark detection')

        ret, self.frame = self.cap.read()
        if ret:
            # self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
            self.frame = cv2.resize(self.frame, (640, 480))
            self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)

            # Landmark
            if self.mode == 0: # Face
                mp_drawing = mp.solutions.drawing_utils
                mp_drawing_styles = mp.solutions.drawing_styles
                mp_face_mesh = mp.solutions.face_mesh

                with mp_face_mesh.FaceMesh(
                        max_num_faces=1,
                        refine_landmarks=True,
                        min_detection_confidence=0.5,
                        min_tracking_confidence=0.5) as face_mesh:

                    results = face_mesh.process(self.frame)

                    self.frame.flags.writeable = True
                    #image = cv2.cvtColor(self.frame, cv2.COLOR_RGB2BGR)
                    if results.multi_face_landmarks:
                        for self.face_landmarks in results.multi_face_landmarks:
                            mp_drawing.draw_landmarks(
                                image=self.frame,
                                landmark_list=self.face_landmarks,
                                connections=mp_face_mesh.FACEMESH_TESSELATION,
                                landmark_drawing_spec=None,
                                connection_drawing_spec=mp_drawing_styles
                                    .get_default_face_mesh_tesselation_style())


                # classify
                if self.face_landmarks and self.loaded_model and self.run_process:
                    F = self.feature_extraction(self.face_landmarks.landmark, 'classify' , 'face')

                    X_test = np.zeros([1, 10], dtype=float);
                    for i in range(len(F)):
                        X_test[0, i] = float(F[i])

                    #scaler = MinMaxScaler()
                    #X_test = scaler.fit_transform(X_test.T)

                    result = self.loaded_model.predict(X_test)
                    predicted_class = np.argmax(result, axis=1)
                    confidence = float(result[0][predicted_class] * 100)
                    threshold = 90

                    if self.mode == 0: # face
                        if confidence >= threshold:
                            if predicted_class == 0:
                                cv2.putText(self.frame, 'Smile ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 1:
                                cv2.putText(self.frame, 'Sad ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 2:
                                cv2.putText(self.frame, 'Angry ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)

            elif self.mode == 1: # hand
                mp_drawing = mp.solutions.drawing_utils
                mp_drawing_styles = mp.solutions.drawing_styles
                mp_hands = mp.solutions.hands

                with mp_hands.Hands(
                        model_complexity=0,
                        min_detection_confidence=0.5,
                        min_tracking_confidence=0.5) as hands:

                    self.frame.flags.writeable = False
                    results = hands.process(self.frame)

                    if results.multi_hand_landmarks:
                        for self.hand_landmarks in results.multi_hand_landmarks:
                            mp_drawing.draw_landmarks(
                                self.frame,
                                self.hand_landmarks,
                                mp_hands.HAND_CONNECTIONS,
                                mp_drawing_styles.get_default_hand_landmarks_style(),
                                mp_drawing_styles.get_default_hand_connections_style())

                # classify
                if self.hand_landmarks and self.loaded_model and self.run_process:
                    F = self.feature_extraction(self.hand_landmarks.landmark, 'classify', 'hand')

                    X_test = np.zeros([1, 5], dtype=float);
                    for i in range(len(F)):
                        X_test[0, i] = float(F[i])

                    #scaler = MinMaxScaler()
                    #X_test = scaler.fit_transform(X_test.T)

                    result = self.loaded_model.predict(X_test)
                    predicted_class = np.argmax(result, axis=1)
                    confidence = float(result[0][predicted_class] * 100)
                    threshold = 90

                    if self.mode == 1: # hand
                        if confidence >= threshold:
                            if predicted_class == 0:
                                cv2.putText(self.frame, 'One ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 1:
                                cv2.putText(self.frame, 'Two ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 2:
                                cv2.putText(self.frame, 'Three ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 3:
                                cv2.putText(self.frame, 'Four ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 4:
                                cv2.putText(self.frame, 'Five ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)

            elif self.mode == 2: # body
                mp_drawing = mp.solutions.drawing_utils
                mp_drawing_styles = mp.solutions.drawing_styles
                mp_pose = mp.solutions.pose

                with mp_pose.Pose(
                        min_detection_confidence=0.5,
                        min_tracking_confidence=0.5) as pose:

                    self.frame.flags.writeable = True
                    self.results_pose_landmarks = pose.process(self.frame)

                    mp_drawing.draw_landmarks(
                        self.frame,
                        self.results_pose_landmarks.pose_landmarks,
                        mp_pose.POSE_CONNECTIONS,
                        landmark_drawing_spec=mp_drawing_styles.get_default_pose_landmarks_style())

                # classify
                if self.results_pose_landmarks.pose_landmarks and self.loaded_model and self.run_process:
                    F = self.feature_extraction(self.results_pose_landmarks.pose_landmarks.landmark, 'classify', 'body')

                    X_test = np.zeros([1, 12], dtype=float);
                    for i in range(len(F)):
                        X_test[0, i] = float(F[i])

                    #scaler = MinMaxScaler()
                    #X_test = scaler.fit_transform(X_test.T)

                    result = self.loaded_model.predict(X_test)
                    predicted_class = np.argmax(result, axis=1)
                    confidence = float(result[0][predicted_class] * 100)
                    threshold = 90

                    if self.mode == 2: # body
                        if confidence >= threshold:
                            if predicted_class == 0:
                                cv2.putText(self.frame, 'Raise right arm ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 1:
                                cv2.putText(self.frame, 'Raise left arm ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)
                            elif predicted_class == 2:
                                cv2.putText(self.frame, 'Spread both arm ' + '{:.2f}'.format(confidence) + ' %', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2,
                                            cv2.LINE_AA)

            #print(self.mode)

            # Show
            prevImg = Image.fromarray(self.frame)
            imgtk = ImageTk.PhotoImage(image=prevImg)
            self.panel.imgtk = imgtk
            self.panel.configure(image=imgtk)
            if not self.cancel:
                self.panel.after(10, self.play_video)
            else:
                self.cancel = False

    def Exit(self):
        self.mainWindow.destroy()
        self.cap.release()


if __name__ == "__main__":

    cls = Detection(0)
